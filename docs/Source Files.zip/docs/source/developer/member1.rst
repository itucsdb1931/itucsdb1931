User, Discomfort, Medication, Family_diseases, Blood_type tables and related functions, html Implemented by Doğu Ozan Kumru
================================
