Patients, Allergy, Surgery, Medical_device tables and related functions Implemented by Talha Çomak
================================
