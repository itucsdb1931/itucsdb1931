Welcome to itucsdb1931's documentation!
=====================================

:Team: itucsdb1931

:Members:

   * Doğu Ozan Kumru
   * Talha Çomak


**Project name is Pre-Diagnosis. 
The aim is provide better communication between doctors and patients. 
Thanks to Pre-Diagnosis, misdiagnosis resulting from incomplete information are avoided.
Doctor does not waste time about patient information, so the inspection time will be shorten.
Doctor know about patient's disease history and hereditary diseases,thus doctor can do better predictable about disease.
This system is designed for doctors to see and update detailed informations about patients.
Doctors can register the system and can login as user. Users can add new patients to the system.
Users can also update informations of patients, but can not delete any user.
Only admins can delete patients. Admins can also delete doctors from the system.**


.. toctree::
   :maxdepth: 1

   user/index
   developer/index
