Home, Login, Register and Admin Pages are Implemented by Doğu Ozan Kumru
================================
