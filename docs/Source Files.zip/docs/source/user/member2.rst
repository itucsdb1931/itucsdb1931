Doctor page and Add new patient pages are Implemented by Talha Çomak
================================
