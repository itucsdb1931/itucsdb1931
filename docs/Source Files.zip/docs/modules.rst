python
======

.. toctree::
   :maxdepth: 4

   configurations
   dbinit
   deneme
   server
