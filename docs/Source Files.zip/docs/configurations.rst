configurations module
=====================

.. automodule:: configurations
   :members:
   :undoc-members:
   :show-inheritance:
